## Tab bar that can show tabs in multiple lines (wrap), when there is not enough horizontal space.
@tool
extends PanelContainer

const CLOSE_BTN_SPACER: String = "    "

const CustomTab := preload("uid://bppomxp4mri2o")
const Plugin := preload("uid://bc0b5v66xdidn")

signal split_toggled

@onready var multiline_tab_bar: HFlowContainer = %MultilineTabBar
@onready var split_btn: Button = %SplitBtn
@onready var popup_btn: Button = %PopupBtn

#region Theme
var tab_hovered: StyleBoxFlat
var tab_focus: StyleBoxFlat
var tab_selected: StyleBoxFlat
var tab_unselected: StyleBoxFlat

var font_selected_color: Color
var font_unselected_color: Color
var font_hovered_color: Color
#endregion

var plugin: Plugin

var show_close_button_always: bool = false : set = set_show_close_button_always
var is_singleline_tabs: bool = false : set = set_singleline_tabs

var tab_group: ButtonGroup = ButtonGroup.new()

# Existing Engine components, set from the plugin
var script_filter_txt: LineEdit
var scripts_item_list: ItemList
var scripts_tab_container: TabContainer

var popup: PopupPanel

var suppress_theme_changed: bool

var split: bool
var split_path: String
var split_icon: Texture2D

var last_drag_over_tab: CustomTab
var drag_marker: ColorRect
var current_tab: CustomTab

#region Plugin and related tab handling processing
func _init() -> void:
	tab_group.pressed.connect(on_new_tab_selected)

func _ready() -> void:
	popup_btn.pressed.connect(show_popup)
	split_btn.gui_input.connect(on_right_click)
	split_btn.toggled.connect(toggle_split.unbind(1))
	split_icon = split_btn.icon

	set_process(false)

	if (plugin == null):
		return

	schedule_update()

func _notification(what: int) -> void:
	if (what == NOTIFICATION_DRAG_END || what == NOTIFICATION_MOUSE_EXIT):
		clear_drag_mark()
		return

	if (what == NOTIFICATION_THEME_CHANGED):
		if (suppress_theme_changed):
			return

		suppress_theme_changed = true
		add_theme_stylebox_override(&"panel", EditorInterface.get_editor_theme().get_stylebox(&"tabbar_background", &"TabContainer"))
		suppress_theme_changed = false

		tab_hovered = EditorInterface.get_editor_theme().get_stylebox(&"tab_hovered", &"TabContainer")
		tab_focus = EditorInterface.get_editor_theme().get_stylebox(&"tab_focus", &"TabContainer")
		tab_selected = EditorInterface.get_editor_theme().get_stylebox(&"tab_selected", &"TabContainer")
		tab_unselected = EditorInterface.get_editor_theme().get_stylebox(&"tab_unselected", &"TabContainer")

		if (drag_marker == null):
			drag_marker = ColorRect.new()
			drag_marker.set_anchors_and_offsets_preset(PRESET_LEFT_WIDE)
			drag_marker.mouse_filter = Control.MOUSE_FILTER_IGNORE
			drag_marker.custom_minimum_size.x = 4 *  EditorInterface.get_editor_scale()
		drag_marker.color = EditorInterface.get_editor_theme().get_color(&"drop_mark_color", &"TabContainer")

		font_hovered_color = EditorInterface.get_editor_theme().get_color(&"font_hovered_color", &"TabContainer")
		font_selected_color = EditorInterface.get_editor_theme().get_color(&"font_selected_color", &"TabContainer")
		font_unselected_color = EditorInterface.get_editor_theme().get_color(&"font_unselected_color", &"TabContainer")

		# If this is called too early.
		if (multiline_tab_bar == null):
			return

		for tab: CustomTab in get_tabs():
			update_tab_style(tab)

func _process(delta: float) -> void:
	sync_tabs_with_item_list()

	if (is_singleline_tabs):
		shift_singleline_tabs()

	set_process(false)

func _shortcut_input(event: InputEvent) -> void:
	if (!event.is_pressed() || event.is_echo()):
		return

	if (!is_visible_in_tree()):
		return

	if (current_tab == null):
		return

	if (plugin.tab_cycle_forward_shc.matches_event(event)):
		get_viewport().set_input_as_handled()

		var tab_count: int = get_tab_count()
		if (tab_count <= 1):
			return

		var index: int = current_tab.get_index()
		var new_tab: int = index + 1
		if (new_tab == tab_count):
			new_tab = 0

		var tab: CustomTab = get_tab(new_tab)
		tab.button_pressed = true
	elif (plugin.tab_cycle_backward_shc.matches_event(event)):
		get_viewport().set_input_as_handled()

		var tab_count: int = get_tab_count()
		if (tab_count <= 1):
			return

		var index: int = current_tab.get_index()
		var new_tab: int = index - 1
		if (new_tab == -1):
			new_tab = tab_count - 1

		var tab: CustomTab = get_tab(new_tab)
		tab.button_pressed = true

func _can_drop_data(at_position: Vector2, data: Variant) -> bool:
	if !(data is Dictionary):
		return false

	var can_drop: bool = data.has("index") && data["index"] != get_tab_count() - 1

	if (can_drop):
		on_drag_over(get_tab(get_tab_count() - 1))

	return can_drop

func _drop_data(at_position: Vector2, data: Variant) -> void:
	if (!_can_drop_data(at_position, data)):
		return

	on_drag_drop(data["index"], get_tab_count() - 1)
#endregion

func schedule_update():
	set_process(true)

func set_split(value: bool) -> void:
	split = value

	if (split):
		var index: int = current_tab.get_index()
		split_path = scripts_item_list.get_item_tooltip(index)

		split_btn.text = scripts_item_list.get_item_text(index)
		split_btn.icon = scripts_item_list.get_item_icon(index)
		split_btn.tooltip_text = split_path
	else:
		split_btn.icon = split_icon
		split_btn.text = ""

func is_split() -> bool:
	return split

func toggle_split():
	split_toggled.emit()

func set_split_disabled(value: bool):
	split_btn.disabled = value

func on_right_click(event: InputEvent):
	if (!split_btn.button_pressed):
		return

	if !(event is InputEventMouseButton):
		return

	var mouse_event: InputEventMouseButton = event

	if (!mouse_event.is_pressed() || mouse_event.button_index != MOUSE_BUTTON_RIGHT):
		return

	split_btn.button_pressed = false

	if (split_path != null && ResourceLoader.exists(split_path)):
		var res: Resource = load(split_path)

		EditorInterface.edit_resource(res)

func on_drag_drop(source_index: int, target_index: int):
	var child: Node = scripts_tab_container.get_child(source_index)
	scripts_tab_container.move_child(child, target_index);

	var tab: CustomTab = get_tab(target_index)
	tab.grab_focus()

func on_drag_over(tab: CustomTab):
	if (last_drag_over_tab == tab):
		return

	# The drag marker should always be orphan when here.
	tab.add_child(drag_marker)

	last_drag_over_tab = tab

func clear_drag_mark():
	if (last_drag_over_tab == null):
		return

	last_drag_over_tab = null
	if (drag_marker.get_parent() != null):
		drag_marker.get_parent().remove_child(drag_marker)

func update_tabs():
	on_scripts_changed()

	for tab: CustomTab in get_tabs():
		update_tab(tab)

func get_tabs() -> Array[Node]:
	return multiline_tab_bar.get_children()

func update_selected_tab():
	update_tab(tab_group.get_pressed_button())

func update_tab(tab: CustomTab):
	if (tab == null):
		return

	var index: int = tab.get_index()

	tab.text = scripts_item_list.get_item_text(index)
	tab.icon = scripts_item_list.get_item_icon(index)
	tab.tooltip_text = scripts_item_list.get_item_tooltip(index)

	update_icon_color(tab, scripts_item_list.get_item_icon_modulate(index))

	if (scripts_item_list.is_selected(index)):
		tab.button_pressed = true
		tab.text += CLOSE_BTN_SPACER
	elif (show_close_button_always):
		tab.text += CLOSE_BTN_SPACER

func get_tab(index: int) -> CustomTab:
	if (index < 0 || index >= get_tab_count()):
		return null

	return multiline_tab_bar.get_child(index)

func get_tab_count() -> int:
	return multiline_tab_bar.get_child_count()

func add_tab() -> CustomTab:
	var tab: CustomTab = CustomTab.new()
	tab.button_group = tab_group

	if (show_close_button_always):
		tab.show_close_button()

	update_tab_style(tab)

	tab.close_pressed.connect(on_tab_close_pressed.bind(tab))
	tab.right_clicked.connect(on_tab_right_click.bind(tab))
	tab.mouse_exited.connect(clear_drag_mark)
	tab.dragged_over.connect(on_drag_over.bind(tab))
	tab.dropped.connect(on_drag_drop)

	multiline_tab_bar.add_child(tab)
	return tab

func update_tab_style(tab: CustomTab):
	tab.add_theme_stylebox_override(&"normal", tab_unselected)
	tab.add_theme_stylebox_override(&"hover", tab_hovered)
	tab.add_theme_stylebox_override(&"hover_pressed", tab_hovered)
	tab.add_theme_stylebox_override(&"focus", tab_focus)
	tab.add_theme_stylebox_override(&"pressed", tab_selected)

	tab.add_theme_color_override(&"font_color", font_unselected_color)
	tab.add_theme_color_override(&"font_hover_color", font_hovered_color)
	tab.add_theme_color_override(&"font_pressed_color", font_selected_color)

func update_icon_color(tab: CustomTab, color: Color):
	tab.add_theme_color_override(&"icon_normal_color", color)
	tab.add_theme_color_override(&"icon_hover_color", color)
	tab.add_theme_color_override(&"icon_hover_pressed_color", color)
	tab.add_theme_color_override(&"icon_pressed_color", color)
	tab.add_theme_color_override(&"icon_focus_color", color)


func on_tab_right_click(tab: CustomTab):
	var index: int = tab.get_index()
	scripts_item_list.item_clicked.emit(index, scripts_item_list.get_local_mouse_position(), MOUSE_BUTTON_RIGHT)

func on_new_tab_selected(tab: CustomTab):
	# Hide and show close button.
	if (!show_close_button_always):
		if (current_tab != null):
			current_tab.hide_close_button()

		if (tab != null):
			tab.show_close_button()

	update_script_text_filter()

	var index: int = tab.get_index()
	if (scripts_item_list != null && !scripts_item_list.is_selected(index)):
		scripts_item_list.select(index)
		scripts_item_list.item_selected.emit(index)
		scripts_item_list.ensure_current_is_visible()

	# Remove spacing from previous tab.
	if (!show_close_button_always && current_tab != null):
		update_tab(current_tab)
	current_tab = tab

## Removes the script filter text and emits the signal so that the tabs stay
## and we do not break anything there.
func update_script_text_filter():
	if (script_filter_txt.text != &""):
		script_filter_txt.text = &""
		script_filter_txt.text_changed.emit(&"")

func on_tab_close_pressed(tab: CustomTab) -> void:
	scripts_item_list.item_clicked.emit(tab.get_index(), scripts_item_list.get_local_mouse_position(), MOUSE_BUTTON_MIDDLE)

func sync_tabs_with_item_list() -> void:
	if (get_tab_count() > scripts_item_list.item_count):
		for index: int in range(get_tab_count() - 1, scripts_item_list.item_count - 1, -1):
			var tab: CustomTab = get_tab(index)

			if (tab == current_tab):
				current_tab = null

			multiline_tab_bar.remove_child(tab)
			free_tab(tab)

	for index: int in scripts_item_list.item_count:
		var tab: CustomTab = get_tab(index)
		if (tab == null):
			tab = add_tab()

		update_tab(tab)

func tab_changed():
	on_scripts_changed()
	update_script_text_filter()

	# When the tab change was not triggered by our component,
	# we need to sync the selection.
	update_tab(get_tab(scripts_tab_container.current_tab))

func on_scripts_changed():
	update_script_text_filter()

	popup_btn.text = "(" + str(scripts_item_list.item_count) + ")"

func script_order_changed() -> void:
	schedule_update()

func set_popup(new_popup: PopupPanel) -> void:
	popup = new_popup

func show_popup() -> void:
	if (popup == null):
		return

	scripts_item_list.get_parent().reparent(popup)
	scripts_item_list.get_parent().visible = true

	popup.size = Vector2(250 * get_editor_scale(), get_parent().size.y - size.y)
	popup.position = popup_btn.get_screen_position() - Vector2(popup.size.x, 0)
	popup.popup()

	script_filter_txt.grab_focus()

func get_editor_scale() -> float:
	return EditorInterface.get_editor_scale()

func set_show_close_button_always(new_value: bool):
	if (show_close_button_always == new_value):
		return

	show_close_button_always = new_value

	if (multiline_tab_bar == null):
		return

	for tab: CustomTab in get_tabs():
		tab.text = scripts_item_list.get_item_text(tab.get_index())
		if (show_close_button_always):
			tab.text += CLOSE_BTN_SPACER
			if (!tab.button_pressed):
				tab.show_close_button()
		else:
			if (!tab.button_pressed):
				tab.hide_close_button()
			else:
				tab.text += CLOSE_BTN_SPACER

func free_tabs():
	if (drag_marker != null):
		drag_marker.free()

	for tab: CustomTab in get_tabs():
		free_tab(tab)

func free_tab(tab: CustomTab):
	if (tab.close_button != null):
		tab.close_button.free()
	tab.free()

#region Singeline handling
func set_singleline_tabs(new_value: bool):
	if (is_singleline_tabs == new_value):
		return

	is_singleline_tabs = new_value

	if (is_singleline_tabs):
		multiline_tab_bar.item_rect_changed.connect(shift_singleline_tabs)
		tab_group.pressed.connect(shift_singleline_tabs.unbind(1))

		shift_singleline_tabs()
	else:
		multiline_tab_bar.item_rect_changed.disconnect(shift_singleline_tabs)
		tab_group.pressed.disconnect(shift_singleline_tabs)

		for tab: CustomTab in get_tabs():
			tab.visible = true

func shift_singleline_tabs():
	if (current_tab == null):
		return

	var tabs: Array[Node] = get_tabs()
	var tab_count: int = tabs.size()
	if (tab_count == 0):
		return

	var tab_bar_width: float = multiline_tab_bar.size.x
	var current_index: int = current_tab.get_index()
	var first: int = current_index
	var last: int = current_index
	var used_width: float = current_tab.size.x

	# Pass 1: Expand through already-visible tabs first
	while (first > 0):
		var prev_tab: Node = tabs[first - 1]
		if (!prev_tab.visible || used_width + prev_tab.size.x > tab_bar_width):
			break
		first -= 1
		used_width += prev_tab.size.x

	while (last < tab_count - 1):
		var next_tab: Node = tabs[last + 1]
		if (!next_tab.visible || used_width + next_tab.size.x > tab_bar_width):
			break
		last += 1
		used_width += next_tab.size.x

	# Pass 2: Fill remaining space with any tabs
	while (first > 0):
		var prev_tab: Node = tabs[first - 1]
		if (used_width + prev_tab.size.x > tab_bar_width):
			break
		first -= 1
		used_width += prev_tab.size.x

	while (last < tab_count - 1):
		var next_tab: Node = tabs[last + 1]
		if (used_width + next_tab.size.x > tab_bar_width):
			break
		last += 1
		used_width += next_tab.size.x

	for index: int in tab_count:
		var tab: Node = tabs.get(index)
		tab.visible = index >= first && index <= last
#endregion
