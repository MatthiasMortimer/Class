extends CharacterBody2D

# function
func _physics_process(delta):
	print(delta)

# Variable
@export var speed: float = 100
@export var rotation_speed: float = 3.5

# Movement
